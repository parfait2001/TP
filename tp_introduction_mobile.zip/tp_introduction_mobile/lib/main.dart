import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/src/painting/image_provider.dart';
import 'dart:io';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;


void main() {
  runApp(const MyApp());
}

Future<http.Response> getUsers(String firsname,String lastname,String mail, String bio , String adresse) {
  return http.post(

    Uri.parse('https://ifri.raycash.net/ifri.postman_collection.json'),
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: jsonEncode(<String, String>{
      'firstname': firsname,
      'lastname': lastname,
      'mail': mail,
      'adresse': adresse
    }),
  );
}

jsonEncode(Map<String, String> map) {
}

class User {
   final String birthday;
   final String lastName ;
   final String firstName;
   final int tel;
   final String mail;
   final String adresse;
   final String bio;


  const User({required this.birthday, required this.lastName, required this.firstName, required this.tel,
    required this.mail, required this.adresse, required this.bio});

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      lastName: json['lastname'],
      firstName: json['firstname'],
      mail:json['mail'],
      adresse: json['adresse'],
      bio: json['birthday'],
      birthday: json['tel'],
      tel: json['tel'],


    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override

  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Tp Introduction mobile'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {


  final _formKey= GlobalKey<FormState>();
  final _birthdayController = new TextEditingController();
  final _lastNameController = new TextEditingController();
  final _firstNameController = new TextEditingController();
  final _telController = new TextEditingController();
  final _mailController = new TextEditingController();
  final _adresseController = new TextEditingController();
  final _bioController = new TextEditingController();

  String? _sexe;
  File? _image;
  //final ImagePicker _picker = ImagePicker();

  Future photoPicked(ImageSource source) async{
   try{
     final _image = await ImagePicker().pickImage(source: source);
     if(_image==null){return;}

     final imageTemporary = File(_image.path);
     setState(() =>this._image= imageTemporary);
   } on PlatformException catch(e){
     print("Echec de telechargement : $e");
   }
  }
  
  @override
  Widget imageprofile(){
    return Stack(children: [
      CircleAvatar(
        radius: 50.0,
        backgroundImage: (_image!= null) ? FileImage(_image!,) as ImageProvider :AssetImage("images/user.png",)
          ),
      Positioned(
          bottom: 10.0,
          right: 30.0,
          child:
          GestureDetector(
            onTap: (){
              showModalBottomSheet(context: context, builder: ((builder)=>bottomsheet()),
              );
            },
            child:Icon(Icons.camera_alt,color: Colors.grey,size: 30.0,)

            ,)
      ),
    ],);
  }

  Widget bottomsheet(){
    return Container(
      height: 100.0,
      width: MediaQuery.of(context).size.width,
      margin: EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 20,
      ),
      child: Column(children: <Widget>[
        Text("Choose your profile",style: TextStyle(fontSize: 20.0),),
        SizedBox(
          height: 16.0,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
          FlatButton.icon(onPressed: (){
           photoPicked(ImageSource.camera);
          }, icon: Icon(Icons.camera),
            label:Text("Camera")
            ,),
          FlatButton.icon(onPressed: (){
            photoPicked(ImageSource.gallery);
          }, icon: Icon(Icons.image),
            label:Text("Gallery")
            ,)
        ],)
      ],
      ),

    );
  }

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
      ),
      body: Center(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child:ListView(children: [
          Column(
            children: [
              Text("Formulaire Inscription",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.blue),),
              SizedBox(height: 15.0,),
              Center(
                child:
                imageprofile(),
                //Image.asset("images/user.png",scale: 4,),
              ),

              SizedBox(height: 30.0,),
              //Initiation du formaulaire
              Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[
                    TextFormField(
                        controller: _lastNameController,
                        keyboardType: TextInputType.name,
                        decoration:InputDecoration(
                            icon:Icon(Icons.person),
                            hintText: "Quel est votre nom",
                            labelText: "Firstname *"
                        ),
                        validator:(String? v){
                          return(v==null||v=="")? "Ce champ est obligatoire": null;
                        }
                    ),
                    TextFormField(
                        controller: _firstNameController,
                        keyboardType: TextInputType.name,
                        decoration:InputDecoration(
                            icon:Icon(Icons.person),
                            hintText: "Quel est votre prénom",
                            labelText: "Lastname *"
                        ),
                        validator:(String? v){
                          return(v==null||v=="")? "Ce champ est obligatoire": null;
                        }
                    ),
                    TextFormField(
                        controller: _birthdayController,
                        keyboardType: TextInputType.name,
                        decoration:InputDecoration(
                            icon:Icon(Icons.cake),
                            hintText: "Quel est votre date d'anniversaire",
                            labelText: "Date d'anniversaire *"
                        ),
                        validator:(String? v){
                          return(v==null||v=="")? "Ce champ est obligatoire": null;
                        }
                    ),
                    DropdownButtonFormField(
                        style: TextStyle(color: Colors.white),
                        decoration: new InputDecoration(
                          icon: Icon(Icons.transgender),
                          hintText: 'Quel est votre sexe',
                          labelText: 'Sexe *',
                        ),
                        value: _sexe,
                        onChanged: (String? v) async{
                          setState(() {
                            _sexe = v;
                          });
                          },
                        items: <String>['Masculin','Feminin'].map<DropdownMenuItem<String>>((String value){
                          return DropdownMenuItem<String>(value:value,
                          child: Text(value,style: TextStyle(color: Colors.black),),
                        );
                        }).toList(),
                        validator: (str) => str==null ? "Ce champ est obligatoire" : null,
                    ),

                    TextFormField(
                        controller: _mailController,
                        keyboardType: TextInputType.name,
                        decoration:InputDecoration(
                            icon:Icon(Icons.person),
                            hintText: "Quel est votre mail",
                            labelText: "Mail *"
                        ),
                        validator:(String? v){
                          return(v==null||v=="")? "Ce champ est obligatoire": null;
                        }
                    ),
                    TextFormField(
                        controller: _telController,
                        keyboardType: TextInputType.number,
                        decoration:InputDecoration(
                            icon:Icon(Icons.phone),
                            hintText: "Quel est votre téléphone",
                            labelText: "Téléphone *"
                        ),
                        validator:(String? v){
                          return(v==null||v=="")? "Ce champ est obligatoire": null;
                        }
                    ),
                    TextFormField(
                        controller: _adresseController,
                        keyboardType: TextInputType.name,
                        decoration:InputDecoration(
                            icon:Icon(Icons.maps_home_work),
                            hintText: "Quel est votre adresse",
                            labelText: "Adresse *"
                        ),
                        validator:(String? v){
                          return(v==null||v=="")? "Ce champ est obligatoire": null;
                        }
                    ),
                SizedBox(height: 10.0,),
                TextFormField(
                  controller: _bioController,
                  decoration: InputDecoration(
                    icon: Icon(Icons.sms),
                    border: UnderlineInputBorder(),
                    hintText: 'Entrer votre bio',
                  ),
                    validator:(String? v){
                      return(v==null||v=="")? "Ce champ est obligatoire": null;
                    }
                ),
                  ],
                ),
              ),
              SizedBox(height: 15.0,),

              ElevatedButton(onPressed:() async{

                if(_formKey.currentState!.validate()){
                  //Enregistrement dans shared preferences
                  final prefs = await SharedPreferences.getInstance();
                  prefs.setString("lastName", _lastNameController.text);
                  prefs.setString("firstName", _firstNameController.text);
                  prefs.setString("telephone", _telController.text);
                  prefs.setString("bio", _bioController.text);
                  prefs.setString("birthday", _birthdayController.text);
                  prefs.setString("mail", _mailController.text);
                  prefs.setString("adresse", _adresseController.text);

                  //Affichage du toast
                  Fluttertoast.showToast(msg: "Vos informations ont été enrégistrés avec succès",
                    toastLength: Toast.LENGTH_LONG,
                    gravity: ToastGravity.BOTTOM,);
                  //Navigator.push(context, MaterialPageRoute(builder: (context) {return todo();}
                //  ),
                  //);
                }
              },
                  child: Text("Valider")
              ),
              SizedBox(height: 15.0,),
            ],
          ),
        ],)


      ),// This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
